tkg-toolkit (formerly dfu-reflash)
=============

A collection of tools used for supporting TKG (TMK Keymap Generator).
