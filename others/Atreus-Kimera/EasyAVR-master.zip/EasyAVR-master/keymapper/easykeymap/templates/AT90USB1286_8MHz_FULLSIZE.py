# This file is auto-generated.  Do not edit.

hex_file_name = 'AT90USB1286_8MHz_FULLSIZE.hex'
device = 'AT90USB1286'
speed = '8MHz'
size = 'FULLSIZE'

layers_map = 0x00000c30
actions_map = 0x00000708
tapkeys_map = 0x000001e0
macro_map = 0x00001158
num_leds_map = 0x000032c4
num_ind_map = 0x000032c3
led_hw_map = 0x00003293
led_map = 0x00003269
num_bl_enab_map = 0x00003268
bl_mask_map = 0x00003258
bl_mode_map = 0x00003158
strobe_cols_map = 0x00003384
strobe_low_map = 0x00003383
num_strobe_map = 0x00003382
num_sense_map = 0x00003381
matrix_init_map = 0x00003375
matrix_strobe_map = 0x000032f1
matrix_sense_map = 0x000032c5
kmac_key_map = None
pw_defs_map = 0x00003385
boot_ptr_map = 0x00003b44
prod_str_map = 0x00003cc5
